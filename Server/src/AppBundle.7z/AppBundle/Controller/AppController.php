<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\ParameterBag;
use AppBundle\Entity\utente;
use AppBundle\Entity\archi;
use AppBundle\Entity\localizzazioni;
use Doctrine\ORM\Query;
use Doctrine\DBAL\Query\QueryBuilder;
use Doctrine\ORM\Query\ResultSetMapping;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use SensioLabs\Security\Command\SecurityCheckerCommand;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\Common\Annotations\AnnotationReader;



class AppController extends Controller
{
  /**
  * @Route("/genus")
  */
  public function showAction()
  {
    return new Response ("Under the sea!");
  }


  /**
  * @Route("/token" ,name="token")
  */
  public function tokenAction(Request $request)
  {
    //PROVA {"token":"dcf698e37c0f436007ca5d4ab1c5528bb65c4972"}
    if ($request->getMethod() == 'POST') {

      $data = json_decode($request->getContent(), true);
      $request->request->replace($data);

      $token = $request->request->get('token');


      $em = $this->getDoctrine()->getManager();
      $u = $em->getRepository('AppBundle:utente')->findBy(array('token' => $token));

      if($u != NULL){

        $response1 = new Response(json_encode(array('token' => 'ok')));
        $response1->headers->set('Content-Type', 'application/json');


      }else{
        $response1 = new Response(json_encode(array('errore' => 'token non valido')));
        $response1->headers->set('Content-Type', 'application/json');
      }

    }

    return $response1;
  }




  /**
  * @Route("/login" ,name="login")
  */
  public function loginAction(Request $request)
  {

    //PROVA {"email":"gb88","password":"pas"}
    if ($request->getMethod() == 'POST') {
      $data = json_decode($request->getContent(), true);
      $request->request->replace($data);

      $email= $request->request->get('email');
      $password = $request->request->get('password');

      $em = $this->getDoctrine()->getManager();
      $u = $em->getRepository('AppBundle:utente')->findBy(array('email' => $email, 'password' => $password));

      if($u != NULL){

        $utente=reset($u);

        $token=sha1(rand()."idstid20152016".$utente->getIdUtente());
        $utente->setToken($token);
        $em->flush();

        $response1 = new Response(json_encode(array('token' => $token)));
        $response1->headers->set('Content-Type', 'application/json');

      }else{
        $response1 = new Response(json_encode(array('errore' => 'email o password errati')));
        $response1->headers->set('Content-Type', 'application/json');
      }

    }


    return $response1;
  }



  /**
  * @Route("/calcola/{id_map}/{nodo1}/{nodo2}")
  */
  public function calcolaK($id_map,$nodo1,$nodo2)
  {
    $criteria1 = array('id_map' => $id_map,
    'nodo1' => $nodo1,
    'nodo2' => $nodo2);
    $em = $this->getDoctrine()->getManager();
    $arr = $em->getRepository('AppBundle:archi')->findBy($criteria1);
    $pv= reset($arr)->getPv();
    $pc= reset($arr)->getPc();
    $plos= reset($arr)->getPlos();
    $pi= reset($arr)->getPi();
    $v= reset($arr)->getV();
    $c= reset($arr)->getC();
    $los= reset($arr)->getLos();
    $i= reset($arr)->getI();
    $k=$pi*$i+$pc*$c+$plos*$los+$pv*$v;
    reset($arr)->setK($k);

    $em->persist(reset($arr));


    $em->flush();

    $response1 = new Response(json_encode(array('k' => $k)));
    $response1->headers->set('Content-Type', 'application/json');

    return($response1);



  }


  /**
  * @Route("/localicazz")
  */
  public function localizzaUtente(Request $request){
    //nuova loc
    //{"id_map":"145","nodo1":"145A3","nodo2":"145EMA3","token":"9c86e190995ecb1dc747e7710b6559d1e7bc7900"}

    if ($request->getMethod() == 'POST') {

      $data = json_decode($request->getContent(), true);
      $request->request->replace($data);

      $id_map = $request->request->get('id_map');
      $nodo1 = $request->request->get('nodo1');
      $nodo2 = $request->request->get('nodo2');

      $token = $request->request->get('token');


      if($id_map!=NULL AND $nodo1!=NULL AND $nodo2!=NULL AND $token!=NULL){
        $criteria1 = array('id_map' => $id_map,
        'nodo1' => $nodo1,
        'nodo2' => $nodo2);

        $em = $this->getDoctrine()->getManager();

        $arco = $em->getRepository('AppBundle:archi')->findBy($criteria1);
        $utente1 = $em->getRepository('AppBundle:utente')->findBy(array('token' => $token));





        if($arco!=NULL AND $utente1!=NULL){
          //ok va bene trovato nodo nel db e forse memorizzare la loc nel db
          //!!!!!!!!!!!!!!!!
          $id_utente= reset ($utente1)->getIdUtente();
          $utenteLoc = $em->getRepository('AppBundle:localizzazioni')->find($id_utente);

          if($utenteLoc==NULL){
            //SE UTENTE NON SI E MAI LOCALIZZATO
            $localizza= new localizzazioni();
            $localizza->setIdMap($id_map);
            $localizza->setNodo1($nodo1);
            $localizza->setNodo2($nodo2);
            $localizza->setIdUtente($id_utente);
            $em->persist($localizza);
            $em->flush();
            $m= 'localizzazione effettuata';

          }else{
            // SE UTENTE GIA LOCALIZZATO , UPDATE DELLA POSIZIONE NEL DB
            $utenteLoc->setIdMap($id_map);
            $utenteLoc->setNodo1($nodo1);
            $utenteLoc->setNodo2($nodo2);

            $em->flush();
            $m= 'localizzazione aggiornata';
          }

        }else{
          $m= 'arco o utente non presenti';
        }

      }else{
        $m= 'Parametri richiesta nulli-sbagliati';
      }

    }else{
      $m='DEVI USARE UNA POST';
    }
    $response1 = new Response(json_encode(array('errore' => $m)));
    $response1->headers->set('Content-Type', 'application/json');
    return $response1;
  }


  /**
  * @Route("/ndom")
  */
  public function localizza(Request $request){

    if ($request->getMethod() == 'POST') {
      $data = json_decode($request->getContent(), true);
      $request->request->replace($data);
      $nodo = $request->request->get('idNodo');


      if($nodo!=NULL){
        $em = $this->getDoctrine()->getManager();
        $nodo1 = $em->getRepository('AppBundle:nodi')->find($nodo);
        if($nodo1!=NULL){
          //ok va bene trovato nodo nel db e forse memorizzare la loc nel db
          //!!!!!!!!!!!!!!!!

          $response1 = new Response(json_encode(array('messaggio' => "tutt appost!")));
          $response1->headers->set('Content-Type', 'application/json');
          return new Response($response1);
        }else{
          $m= 'nodo non presente';
        }
      }else{
        $m= 'nodo nullo';

      }
    }else{
      $m='DEVI USARE UNA POST';
    }
    $response1 = new Response(json_encode(array('errore' => $m)));
    $response1->headers->set('Content-Type', 'application/json');
    return new Response($response1);
  }

  // METODO LOS DA MODIFICARE !!
  /**
  * @Route("/a/{id_map}/{nodo1}/{nodo2}/{persone}")
  */
  public function calcolaLOS($id_map,$nodo1,$nodo2,$persone)
  {
    // FORMULA kp=pi*i + pc*C+plos*LOS+ pv*V
    $em = $this->getDoctrine()->getManager();
    $arco = $em->getRepository('AppBundle:archi')->findBy(array('id_map' => $id_map, 'nodo1' => $nodo1, 'nodo2' => $nodo2));
    $area= reset ($arco)->getArea();

    if($persone==0){
      $rapporto=4;
    }else{
      $rapporto=$area/$persone;
    }
    $LOS;

    switch($rapporto){
      case ($rapporto>3.7):
      $LOS=0;
      break;

      case ($rapporto>=2.2 AND  $rapporto<=3.7):
      $LOS=0.33;
      break;

      case ($rapporto>=1.4 AND $rapporto<2.2):
      $LOS=0.67;
      break;

      case ($rapporto>=0.75 AND $rapporto<1.4):
      $LOS=1;
      break;

      case ($rapporto<0.75):
      $LOS=3;
      break;
    }

    reset ($arco)->setLos($LOS);
    $kp222= 'ciao';
    // tells Doctrine you want to (eventually) save the Product (no queries yet)
    $em->persist(reset ($arco));

    // actually executes the queries (i.e. the INSERT query)
    $em->flush();
    //$a= reset ($arco)->setK($kp);
    //  $utenteEmail = $this->getDoctrine()->getRepository('AppBundle:utente')->findBy($criteria2);
    return new Response($kp222);
  }





  /**
  * @Route("/registra")
  */
  public function registraAction(Request $request)
  {
    if ($request->getMethod() == 'POST') {
      //{"nome":"Mario","cognome":"Rossi","password":"password","email":"mr86@gmail.com"}

      $data = json_decode($request->getContent(), true);
      $request->request->replace($data);
      $nome = $request->request->get('nome');
      $cognome = $request->request->get('cognome');
      $email = $request->request->get('email');
      $password = $request->request->get('password');

      $utente = new utente();

      $utente->setNome($nome);
      $utente->setCognome($cognome);
      $utente->setPassword($password);
      $utente->setEmail($email);

      $em = $this->getDoctrine()->getEntityManager();

      $validator = $this->get('validator');
      $errors = $validator->validate($utente);

      if (count($errors) > 0) {
        //  return new Response(print_r($errors, true));
        //$response1 = new Response(json_encode(array('errore' => $errors)));
        //  $response1 = new Response(print_r($errors, true));
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new GetSetMethodNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        /**/
        foreach ($errors as $error)
        {
          $campo = $error->getPropertyPath();
          $messaggio = $error->getMessage();
          //o fare così:
          //$erroriBrutti[$campo] = $messaggio;
          //$ciao[]=$erroriBrutti;
          $definitivo[][$campo]=$messaggio;
        }
        /**/

        $response1 = new Response(json_encode(array('stato' => 'KO','risultato' =>$definitivo)));


        $response1->headers->set('Content-Type', 'application/json');
      }else{

        $criteria2 = array('email' => $email);
        $utenteEmail = $this->getDoctrine()->getRepository('AppBundle:utente')->findBy($criteria2);

        if ($utenteEmail) {
          $r= "email non disponibile";
          $response=(array(array('email' => $r)));
          $response1 = new Response(json_encode(array('stato' => 'KO','risultato' =>$response)));
          $response1->headers->set('Content-Type', 'application/json');
        }else{
          //email disponibile
          $em->persist($utente);
          $em->flush();
          //SE UTENTE
          $token=sha1(rand()."idstid20152016".$utente->getIdUtente());
          $utente->setToken($token);
          $tokenJ=(array(array('token' => $token)));

          $response1 = new Response(json_encode(array('stato' => 'OK','risultato' =>$tokenJ)));
          //var_dump($response1);
          $response1->headers->set('Content-Type', 'application/json');
        }


      }
      return ($response1);

    }
    $response1 = new Response(json_encode(array('method' => 'deve essere post')));
    $response1->headers->set('Content-Type', 'application/json');
    return ($response1);

  }





  //METODO FORSE DA CANCELLARE
  /**
  * @Route("/dd/{tabella}")
  */
  public function jsonTableDb($tabella)
  {

    //$serializer = $container->get('jms_serializer');
    // $serializer->serialize($data, $format);
    // $data = $serializer->deserialize($inputStr, $typeName, $format);

    $encoders = array(new XmlEncoder(), new JsonEncoder());
    $normalizers = array(new GetSetMethodNormalizer());
    $serializer = new Serializer($normalizers, $encoders);

    $repository = $this->getDoctrine()->getRepository('AppBundle:'.$tabella);
    $data = $repository->findAll();

    //$json = $serializer->serialize($data, 'json');

    $json = $serializer->serialize($data, 'json');

    //$json = new JsonResponse($messagesArr);

    if (!$json) {
      throw $this->createNotFoundException(
      'No messages found'
    );
  }

  return new Response($json);

}


//METODO FORSE DA CANCELLARE !!
/**
* @Route("/jsonK")
*/
public function jsonK(Request $request){
  //($id_map,$nodo1,$nodo2)
  //{"id_map":"145","nodo1":"145A3","nodo2":"145EMA3"}
  if ($request->getMethod() == 'POST') {
    $data = json_decode($request->getContent(), true);
    $request->request->replace($data);
    $id_map = $request->request->get('id_map');
    $nodo1 = $request->request->get('nodo1');
    $nodo2 = $request->request->get('nodo2');
    $em = $this->getDoctrine()->getManager();
    $arco = $em->getRepository('AppBundle:archi')->findBy(array('id_map' => $id_map, 'nodo1' => $nodo1, 'nodo2' => $nodo2));
    $k = reset($arco)->getK();
    $array = array(
      'id_map' => $id_map,
      'nodo1' => $nodo1,
      'nodo2' => $nodo2,
      'k' => $k
    );
    $response1 = new Response(json_encode($array));
    $response1->headers->set('Content-Type', 'application/json');
    return new Response($response1);
  }
}



}
